from pathlib import Path
from datetime import datetime
import re

ROOT = Path('/Users/MN/lanpinktattoo')
ts = datetime.now().strftime('%Y%m%d_%H%M%S')

def backup(path: Path):
    if path.exists():
        bak = path.with_name(path.name + f'.bak_split_css_{ts}')
        bak.write_text(path.read_text(encoding='utf-8'), encoding='utf-8')
        print(f'BACKUP: {path} -> {bak}')

components = ROOT / 'assets' / 'css' / 'components'
components.mkdir(parents=True, exist_ok=True)

hero_css = components / 'hero.css'
promo_hero_css = components / 'promo-hero.css'
promo_sticky_css = components / 'promo-sticky.css'
promo_hero_partial = ROOT / 'layouts' / 'partials' / 'promo-hero.html'
head_partial = ROOT / 'layouts' / 'partials' / 'head.html'

# 1) Backup các file nhạy cảm
for p in [hero_css, promo_hero_css, promo_sticky_css, promo_hero_partial, head_partial]:
    backup(p)

# 2) Giữ hero.css hiện tại, chỉ thêm comment nếu chưa có marker
if hero_css.exists():
    s = hero_css.read_text(encoding='utf-8')
    if 'HERO ONLY - PROMO CSS MOVED OUT' not in s:
        s = '/* HERO ONLY - PROMO CSS MOVED OUT TO promo-hero.css / promo-sticky.css */\n\n' + s
        hero_css.write_text(s, encoding='utf-8')

# 3) Tách CSS inline trong promo-hero.html ra promo-hero.css, giữ nguyên style hiện có để không vỡ giao diện
promo_css_parts = []
if promo_hero_partial.exists():
    html = promo_hero_partial.read_text(encoding='utf-8')
    style_blocks = re.findall(r'<style[^>]*>([\s\S]*?)</style>', html, flags=re.I)
    if style_blocks:
        promo_css_parts.extend(block.strip() for block in style_blocks if block.strip())
        html_no_style = re.sub(r'\n?\s*<style[^>]*>[\s\S]*?</style>\s*\n?', '\n', html, flags=re.I)
        promo_hero_partial.write_text(html_no_style, encoding='utf-8')
        print(f'OK: đã tách {len(style_blocks)} style block khỏi layouts/partials/promo-hero.html')
    else:
        print('INFO: promo-hero.html không có style inline để tách.')

# Nếu chưa lấy được CSS từ partial, tạo bản fallback an toàn cho promo hero
if promo_css_parts:
    promo_hero_css.write_text(
        '/* PROMO HERO - extracted from layouts/partials/promo-hero.html */\n\n' + '\n\n'.join(promo_css_parts).strip() + '\n',
        encoding='utf-8'
    )
else:
    fallback = '''/* PROMO HERO - fallback safe style */
.lanpink-promo-hero {
  width: min(100% - 2rem, 1180px);
  margin: 1.25rem auto 2rem;
  padding: 0;
}

.lanpink-promo-hero__inner {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 1.5rem;
  align-items: center;
  border-radius: 28px;
  padding: clamp(1.25rem, 3vw, 2.2rem);
  background:
    radial-gradient(circle at 92% 12%, rgba(255,255,255,.46), transparent 28%),
    linear-gradient(135deg, #fff7fb, #ffe2ef 48%, #f9a8d4);
  border: 1px solid rgba(236,72,153,.18);
  box-shadow: 0 20px 54px rgba(236,72,153,.16);
  color: #3b1b28;
}

.lanpink-promo-hero__badge {
  display: inline-flex;
  align-items: center;
  width: fit-content;
  margin-bottom: .75rem;
  padding: .38rem .8rem;
  border-radius: 999px;
  background: rgba(255,255,255,.66);
  color: #be185d;
  font-size: .78rem;
  font-weight: 900;
}

.lanpink-promo-hero h2 {
  margin: 0;
  color: #2b1721;
  font-size: clamp(1.55rem, 3vw, 2.55rem);
  line-height: 1.08;
  letter-spacing: -.035em;
}

.lanpink-promo-hero p {
  max-width: 720px;
  margin: .75rem 0 0;
  color: #6b5260;
  line-height: 1.65;
}

.lanpink-promo-hero__meta {
  margin-top: .75rem;
  color: #8b5f72;
  font-size: .92rem;
  font-weight: 750;
}

.lanpink-promo-hero__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: fit-content;
  margin-top: 1rem;
  border-radius: 999px;
  padding: .78rem 1.1rem;
  background: linear-gradient(135deg, #ec4899, #db2777);
  color: #fff;
  font-weight: 900;
  text-decoration: none;
  box-shadow: 0 14px 32px rgba(236,72,153,.24);
}

.lanpink-promo-hero__sale {
  display: grid;
  place-items: center;
  width: 150px;
  height: 150px;
  border-radius: 999px;
  background: rgba(255,255,255,.62);
  color: #db2777;
  font-size: 34px;
  font-weight: 950;
  letter-spacing: -.05em;
  box-shadow: inset 0 0 0 1px rgba(236,72,153,.16);
}

html[data-theme="dark"] .lanpink-promo-hero__inner {
  background:
    radial-gradient(circle at 92% 12%, rgba(249,168,212,.2), transparent 32%),
    linear-gradient(135deg, rgba(39,39,42,.95), rgba(131,24,67,.74));
  border-color: rgba(249,168,212,.16);
  color: #fff7fb;
}

html[data-theme="dark"] .lanpink-promo-hero h2 {
  color: #fff7fb;
}

html[data-theme="dark"] .lanpink-promo-hero p,
html[data-theme="dark"] .lanpink-promo-hero__meta {
  color: #ead7e2;
}

@media (max-width: 768px) {
  .lanpink-promo-hero {
    width: min(100% - 1rem, 1180px);
    margin: .9rem auto 1.25rem;
  }

  .lanpink-promo-hero__inner {
    grid-template-columns: 1fr;
    border-radius: 22px;
  }

  .lanpink-promo-hero__sale {
    display: none;
  }

  .lanpink-promo-hero__btn {
    width: 100%;
  }
}
'''
    promo_hero_css.write_text(fallback, encoding='utf-8')
    print('OK: đã tạo promo-hero.css fallback an toàn')

# 4) Tạo promo-sticky.css riêng, mobile/tablet ẩn hoàn toàn
promo_sticky_css.write_text('''/* PROMO STICKY - desktop only, hidden on mobile/tablet */
.lanpink-promo-sticky {
  display: none;
}

@media (min-width: 1280px) {
  .lanpink-promo-sticky {
    display: block;
    position: fixed;
    left: 18px;
    top: 130px;
    width: 230px;
    z-index: 20;
    padding: 16px 15px;
    border-radius: 20px;
    background: linear-gradient(135deg, #fff7fb, #ffe2ef);
    border: 1px solid rgba(214, 72, 126, .22);
    box-shadow: 0 16px 38px rgba(70, 28, 42, .14);
    color: #3b1b28;
  }

  .lanpink-promo-sticky__badge {
    display: inline-block;
    margin-bottom: 8px;
    padding: 4px 9px;
    border-radius: 999px;
    background: rgba(214, 72, 126, .12);
    font-size: 12px;
    font-weight: 800;
  }

  .lanpink-promo-sticky__title {
    margin-bottom: 7px;
    font-size: 17px;
    font-weight: 900;
    line-height: 1.25;
    color: #2b1721;
  }

  .lanpink-promo-sticky p {
    margin: 0 0 12px;
    font-size: 13px;
    line-height: 1.45;
    color: #6b5260;
  }

  .lanpink-promo-sticky__btn,
  .lanpink-promo-sticky a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    padding: 9px 10px;
    border-radius: 999px;
    background: #d6487e;
    color: #fff;
    text-decoration: none;
    font-size: 13px;
    font-weight: 900;
  }

  html[data-theme="dark"] .lanpink-promo-sticky {
    background: linear-gradient(135deg, rgba(39,39,42,.96), rgba(131,24,67,.78));
    border-color: rgba(249,168,212,.16);
    box-shadow: 0 18px 44px rgba(0,0,0,.28);
    color: #fff7fb;
  }

  html[data-theme="dark"] .lanpink-promo-sticky__badge {
    background: rgba(249,168,212,.14);
    color: #fbcfe8;
  }

  html[data-theme="dark"] .lanpink-promo-sticky__title {
    color: #fff7fb;
  }

  html[data-theme="dark"] .lanpink-promo-sticky p {
    color: #ead7e2;
  }
}
''', encoding='utf-8')
print('OK: đã tạo promo-sticky.css riêng')

# 5) Include CSS mới vào head.html ngay sau hero.css
if not head_partial.exists():
    raise SystemExit('Không tìm thấy layouts/partials/head.html để include CSS mới')

head = head_partial.read_text(encoding='utf-8')
for css in ['css/components/promo-hero.css', 'css/components/promo-sticky.css']:
    if css not in head:
        marker = '"css/components/hero.css"'
        if marker in head:
            head = head.replace(marker, marker + f'\n  "{css}"', 1)
        else:
            raise SystemExit(f'Không tìm thấy {marker} trong head.html để chèn {css}')
head_partial.write_text(head, encoding='utf-8')
print('OK: đã include promo-hero.css và promo-sticky.css trong head.html')

# 6) Kiểm tra cơ bản
for p in [hero_css, promo_hero_css, promo_sticky_css, promo_hero_partial, head_partial]:
    if p.exists():
        print(f'CHECK: {p.relative_to(ROOT)}')

print('DONE: split CSS an toàn xong. Chạy: hugo --gc --minify')
